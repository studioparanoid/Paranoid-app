"use client";

import Link from "next/link";
import { useState } from "react";
import { supabase } from "@/lib/supabase/public";

const categories = [
  "Concertos",
  "Festivais",
  "DJ Sets",
  "Cinema",
  "Exposições",
  "Mercados",
  "Workshops",
  "Teatro",
  "Outros",
];

const cities = [
  "Pombal",
  "Leiria",
  "Coimbra",
  "Figueira da Foz",
  "Caldas da Rainha",
  "Marinha Grande",
];

type TicketMode = "none" | "external" | "internal";

type VenueRow = {
  id: string;
  slug: string;
  name: string;
};

type OrganizerRow = {
  id: string;
  slug: string;
  name: string;
};

type ArtistRow = {
  id: string;
  slug: string;
  name: string;
};

function slugify(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "");
}

function normalizeExternalUrl(value: string) {
  const cleanValue = value.trim();

  if (!cleanValue) {
    return null;
  }

  if (cleanValue.startsWith("http://") || cleanValue.startsWith("https://")) {
    return cleanValue;
  }

  return `https://${cleanValue}`;
}

function formatPriceValue(value: string) {
  const cleanPrice = value.trim();

  if (!cleanPrice) {
    return "";
  }

  if (
    cleanPrice.toLowerCase() === "gratis" ||
    cleanPrice.toLowerCase() === "grátis" ||
    cleanPrice === "0"
  ) {
    return "Entrada livre";
  }

  if (!cleanPrice.includes("€") && /^\d+([,.]\d{1,2})?$/.test(cleanPrice)) {
    return `${cleanPrice.replace(".", ",")}€`;
  }

  return cleanPrice;
}

function formatDateForDisplay(value: string) {
  if (!value) {
    return "";
  }

  const parts = value.split("-");

  if (parts.length !== 3) {
    return value;
  }

  return `${parts[2]}.${parts[1]}.${parts[0]}`;
}

function buildDisplayDate(startDate: string, endDate: string, isMultiDay: boolean) {
  if (!startDate) {
    return "Data por definir";
  }

  if (isMultiDay && endDate && endDate !== startDate) {
    return `${formatDateForDisplay(startDate)} — ${formatDateForDisplay(
      endDate
    )}`;
  }

  return formatDateForDisplay(startDate);
}

function getStartAt(startDate: string, displayTime: string | null) {
  if (!startDate) {
    return new Date().toISOString();
  }

  const cleanTime = displayTime || "00:00";
  const timeWithSeconds =
    cleanTime.split(":").length === 2 ? `${cleanTime}:00` : cleanTime;

  return `${startDate}T${timeWithSeconds}+00:00`;
}

function getEndAt(startDate: string, endDate: string, isMultiDay: boolean) {
  if (!startDate) {
    return new Date().toISOString();
  }

  const finalEndDate = isMultiDay && endDate ? endDate : startDate;

  return `${finalEndDate}T23:59:00+00:00`;
}

function getArtistNames(artistsText: string) {
  const names = artistsText
    .split(",")
    .map((name) => name.trim())
    .filter(Boolean);

  return Array.from(new Set(names));
}

async function createUniqueEventSlug(title: string) {
  const baseSlug = slugify(title) || crypto.randomUUID();
  let candidate = baseSlug;
  let count = 1;

  while (true) {
    const { data, error } = await supabase
      .from("events")
      .select("id")
      .eq("slug", candidate)
      .maybeSingle();

    if (error) {
      throw new Error(error.message);
    }

    if (!data) {
      return candidate;
    }

    count += 1;
    candidate = `${baseSlug}-${count}`;
  }
}

async function findOrCreateVenue(name: string, city: string) {
  const cleanName = name.trim();

  if (!cleanName) {
    return null;
  }

  const slug = slugify(cleanName);

  const { data: existingVenue, error: existingError } = await supabase
    .from("venues")
    .select("id,slug,name")
    .eq("slug", slug)
    .maybeSingle();

  if (existingError) {
    throw new Error(existingError.message);
  }

  if (existingVenue) {
    return (existingVenue as VenueRow).id;
  }

  const { data: createdVenue, error: createError } = await supabase
    .from("venues")
    .insert({
      slug,
      name: cleanName,
      city,
      address: null,
      description: null,
      instagram: null,
    })
    .select("id,slug,name")
    .single();

  if (createError) {
    throw new Error(createError.message);
  }

  return (createdVenue as VenueRow).id;
}

async function findOrCreateOrganizer(name: string, city: string) {
  const cleanName = name.trim();

  if (!cleanName) {
    return null;
  }

  const slug = slugify(cleanName);

  const { data: existingOrganizer, error: existingError } = await supabase
    .from("organizers")
    .select("id,slug,name")
    .eq("slug", slug)
    .maybeSingle();

  if (existingError) {
    throw new Error(existingError.message);
  }

  if (existingOrganizer) {
    return (existingOrganizer as OrganizerRow).id;
  }

  const { data: createdOrganizer, error: createError } = await supabase
    .from("organizers")
    .insert({
      slug,
      name: cleanName,
      city,
      description: null,
      pack: null,
      verified: false,
    })
    .select("id,slug,name")
    .single();

  if (createError) {
    throw new Error(createError.message);
  }

  return (createdOrganizer as OrganizerRow).id;
}

async function findOrCreateArtist(name: string, city: string) {
  const cleanName = name.trim();

  if (!cleanName) {
    return null;
  }

  const slug = slugify(cleanName);

  const { data: existingArtist, error: existingError } = await supabase
    .from("artists")
    .select("id,slug,name")
    .eq("slug", slug)
    .maybeSingle();

  if (existingError) {
    throw new Error(existingError.message);
  }

  if (existingArtist) {
    return (existingArtist as ArtistRow).id;
  }

  const { data: createdArtist, error: createError } = await supabase
    .from("artists")
    .insert({
      slug,
      name: cleanName,
      city,
      genres: null,
      description: null,
      instagram: null,
      bandcamp: null,
    })
    .select("id,slug,name")
    .single();

  if (createError) {
    throw new Error(createError.message);
  }

  return (createdArtist as ArtistRow).id;
}

async function attachArtistsToEvent({
  eventId,
  artistsText,
  city,
}: {
  eventId: string;
  artistsText: string;
  city: string;
}) {
  const artistNames = getArtistNames(artistsText);

  if (artistNames.length === 0) {
    return;
  }

  const artistIds: string[] = [];

  for (const artistName of artistNames) {
    const artistId = await findOrCreateArtist(artistName, city);

    if (artistId) {
      artistIds.push(artistId);
    }
  }

  if (artistIds.length === 0) {
    return;
  }

  const rows = artistIds.map((artistId) => ({
    event_id: eventId,
    artist_id: artistId,
  }));

  const { error } = await supabase.from("event_artists").insert(rows);

  if (error) {
    throw new Error(error.message);
  }
}

export function AdminEventCreateClient() {
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const [title, setTitle] = useState("");
  const [organizer, setOrganizer] = useState("");
  const [artistsText, setArtistsText] = useState("");
  const [category, setCategory] = useState("Concertos");
  const [city, setCity] = useState("Pombal");
  const [venue, setVenue] = useState("");
  const [eventDate, setEventDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [isMultiDay, setIsMultiDay] = useState(false);
  const [eventTime, setEventTime] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [featured, setFeatured] = useState(false);

  const [ticketMode, setTicketMode] = useState<TicketMode>("none");
  const [ticketUrl, setTicketUrl] = useState("");
  const [ticketPrice, setTicketPrice] = useState("");
  const [ticketCapacity, setTicketCapacity] = useState("");
  const [ticketButtonLabel, setTicketButtonLabel] = useState("Comprar bilhete");
  const [instagramUrl, setInstagramUrl] = useState("");

  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);

  function handleCategoryChange(value: string) {
    setCategory(value);

    if (value === "Festivais") {
      setIsMultiDay(true);

      if (eventDate && !endDate) {
        setEndDate(eventDate);
      }
    }
  }

  function handleMultiDayChange(value: boolean) {
    setIsMultiDay(value);

    if (!value) {
      setEndDate("");
    }

    if (value && eventDate && !endDate) {
      setEndDate(eventDate);
    }
  }

  function handleEventDateChange(value: string) {
    setEventDate(value);

    if (isMultiDay && !endDate) {
      setEndDate(value);
    }
  }

  function handleTicketModeChange(value: TicketMode) {
    setTicketMode(value);

    if (value === "none") {
      setTicketUrl("");
      setTicketPrice("");
      setTicketCapacity("");
      setTicketButtonLabel("Comprar bilhete");
    }

    if (value === "external") {
      setTicketButtonLabel("Bilhetes / inscrição");
    }

    if (value === "internal") {
      setTicketUrl("");
      setTicketButtonLabel("Comprar na Paranoid");
    }
  }

  function handleImageChange(file: File | null) {
    setMessage("");

    if (!file) {
      setSelectedImageFile(null);
      setImagePreviewUrl(null);
      return;
    }

    const allowedTypes = ["image/jpeg", "image/png", "image/webp"];

    if (!allowedTypes.includes(file.type)) {
      setMessage("A imagem tem de ser JPG, PNG ou WEBP.");
      return;
    }

    const maxSize = 5 * 1024 * 1024;

    if (file.size > maxSize) {
      setMessage("A imagem tem de ter menos de 5MB.");
      return;
    }

    setSelectedImageFile(file);
    setImagePreviewUrl(URL.createObjectURL(file));
  }

  async function uploadSelectedImage() {
    if (!selectedImageFile) {
      return null;
    }

    const extension =
      selectedImageFile.name.split(".").pop()?.toLowerCase() || "jpg";

    const filePath = `events/${crypto.randomUUID()}.${extension}`;

    const { error: uploadError } = await supabase.storage
      .from("event-images")
      .upload(filePath, selectedImageFile, {
        cacheControl: "3600",
        upsert: false,
        contentType: selectedImageFile.type,
      });

    if (uploadError) {
      throw new Error(uploadError.message);
    }

    const { data } = supabase.storage
      .from("event-images")
      .getPublicUrl(filePath);

    return data.publicUrl;
  }

  function resetForm() {
    setTitle("");
    setOrganizer("");
    setArtistsText("");
    setCategory("Concertos");
    setCity("Pombal");
    setVenue("");
    setEventDate("");
    setEndDate("");
    setIsMultiDay(false);
    setEventTime("");
    setPrice("");
    setDescription("");
    setFeatured(false);
    setTicketMode("none");
    setTicketUrl("");
    setTicketPrice("");
    setTicketCapacity("");
    setTicketButtonLabel("Comprar bilhete");
    setInstagramUrl("");
    setSelectedImageFile(null);
    setImagePreviewUrl(null);
  }

  async function handleCreateEvent() {
    setMessage("");

    if (!title || !organizer || !city || !venue || !eventDate) {
      setMessage(
        "Preenche pelo menos nome do evento, organizador, cidade, espaço e data."
      );
      return;
    }

    if (isMultiDay && !endDate) {
      setMessage("Mete a data de fim do festival/evento.");
      return;
    }

    if (isMultiDay && endDate < eventDate) {
      setMessage("A data de fim não pode ser antes da data de início.");
      return;
    }

    if (ticketMode === "external" && !ticketUrl.trim()) {
      setMessage("Se escolheste bilheteira externa, mete o link.");
      return;
    }

    if (ticketMode === "internal" && !ticketPrice.trim()) {
      setMessage("Se escolheste bilheteira Paranoid, mete o preço do bilhete.");
      return;
    }

    setSaving(true);

    try {
      const eventSlug = await createUniqueEventSlug(title);
      const imageUrl = await uploadSelectedImage();

      const venueId = await findOrCreateVenue(venue, city);
      const organizerId = await findOrCreateOrganizer(organizer, city);

      const finalEndDate = isMultiDay ? endDate || eventDate : eventDate;
      const displayDate = buildDisplayDate(eventDate, finalEndDate, isMultiDay);
      const startAt = getStartAt(eventDate, eventTime || null);
      const endAt = getEndAt(eventDate, finalEndDate, isMultiDay);

      const { data: createdEvent, error } = await supabase
        .from("events")
        .insert({
          slug: eventSlug,
          title,
          city,
          venue_id: venueId,
          venue_name: venue,
          organizer_id: organizerId,
          organizer_name: organizer,
          start_at: startAt,
          end_at: endAt,
          start_date: eventDate,
          end_date: finalEndDate,
          is_multi_day: isMultiDay,
          display_date: displayDate,
          display_time: eventTime || "Hora por definir",
          category,
          price: price || "Preço por definir",
          description: description || "",
          image_url: imageUrl,

          ticket_mode: ticketMode,
          ticket_url: ticketMode === "external" ? normalizeExternalUrl(ticketUrl) : null,
          ticket_price: ticketMode === "internal" ? ticketPrice || null : null,
          ticket_capacity:
            ticketMode === "internal" && ticketCapacity
              ? Number(ticketCapacity)
              : null,
          ticket_button_label:
            ticketMode !== "none" ? ticketButtonLabel || null : null,
          instagram_url: normalizeExternalUrl(instagramUrl),

          featured,
          status: "published",
        })
        .select("id,slug")
        .single();

      if (error) {
        throw new Error(error.message);
      }

      await attachArtistsToEvent({
        eventId: createdEvent.id,
        artistsText,
        city,
      });

      setSaving(false);
      setMessage(`Evento criado: /eventos/${createdEvent.slug}`);
      resetForm();
    } catch (error) {
      setSaving(false);
      setMessage(
        `Erro ao criar evento: ${
          error instanceof Error ? error.message : "erro desconhecido"
        }`
      );
    }
  }

  return (
    <section className="mt-8 rounded-[2.5rem] border border-zinc-800 bg-zinc-950 p-5 lg:mt-12 lg:p-8">
      <div className="grid gap-6 lg:grid-cols-[1fr_0.7fr]">
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-red-700">
            Admin
          </p>

          <h2 className="mt-3 text-4xl font-black leading-none lg:text-6xl">
            Criar evento.
          </h2>

          <p className="mt-4 text-sm leading-relaxed text-zinc-500">
            Cria eventos diretamente como Paranoid, já com bilheteira interna,
            externa ou sem bilhetes.
          </p>
        </div>

        <div className="rounded-[2rem] border border-zinc-800 bg-black p-5">
          <p className="text-xs uppercase tracking-[0.25em] text-red-700">
            Pré-visualização
          </p>

          <h3 className="mt-3 text-2xl font-black leading-tight">
            {title || "Nome do evento"}
          </h3>

          <div className="mt-4 space-y-1 text-sm text-zinc-500">
            <p>{category}</p>
            <p>{eventDate || "Data por definir"}</p>
            <p>{eventTime || "Hora por definir"}</p>
            <p>{[venue, city].filter(Boolean).join(" · ") || "Local"}</p>
            <p>{price || "Preço por definir"}</p>
            {ticketMode === "external" && <p>Bilheteira externa</p>}
            {ticketMode === "internal" && (
              <p>Bilheteira Paranoid · {ticketPrice || "preço por definir"}</p>
            )}
          </div>
        </div>
      </div>

      <div className="mt-8 grid gap-5 lg:grid-cols-2">
        <div className="lg:col-span-2">
          <label className="mb-2 block text-sm font-bold text-zinc-300">
            Poster / imagem
          </label>

          <input
            type="file"
            accept="image/png,image/jpeg,image/webp"
            onChange={(event) =>
              handleImageChange(event.target.files?.[0] || null)
            }
            className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-sm text-zinc-400 file:mr-4 file:rounded-full file:border-0 file:bg-[#f2f1ec] file:px-4 file:py-2 file:text-sm file:font-black file:text-black"
          />
        </div>

        {imagePreviewUrl && (
          <div
            className="h-72 rounded-[2rem] bg-cover bg-center lg:col-span-2 lg:h-96"
            style={{ backgroundImage: `url(${imagePreviewUrl})` }}
          />
        )}

        <div>
          <label className="mb-2 block text-sm font-bold text-zinc-300">
            Nome do evento
          </label>

          <input
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="Ex: Noite Paranoid Vol. I"
            className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none placeholder:text-zinc-600 focus:border-red-900"
          />
        </div>

        <div>
          <label className="mb-2 block text-sm font-bold text-zinc-300">
            Organizador
          </label>

          <input
            value={organizer}
            onChange={(event) => setOrganizer(event.target.value)}
            placeholder="Nome do coletivo, sala ou promotor"
            className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none placeholder:text-zinc-600 focus:border-red-900"
          />
        </div>

        <div className="lg:col-span-2">
          <label className="mb-2 block text-sm font-bold text-zinc-300">
            Artistas / bandas / DJs
          </label>

          <input
            value={artistsText}
            onChange={(event) => setArtistsText(event.target.value)}
            placeholder="Separar por vírgulas"
            className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none placeholder:text-zinc-600 focus:border-red-900"
          />
        </div>

        <div>
          <label className="mb-2 block text-sm font-bold text-zinc-300">
            Categoria
          </label>

          <select
            value={category}
            onChange={(event) => handleCategoryChange(event.target.value)}
            className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none focus:border-red-900"
          >
            {categories.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="mb-2 block text-sm font-bold text-zinc-300">
            Cidade
          </label>

          <select
            value={city}
            onChange={(event) => setCity(event.target.value)}
            className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none focus:border-red-900"
          >
            {cities.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </div>

        <div className="lg:col-span-2">
          <label className="mb-2 block text-sm font-bold text-zinc-300">
            Espaço / local
          </label>

          <input
            value={venue}
            onChange={(event) => setVenue(event.target.value)}
            placeholder="Ex: Stereogun, Teatro-Cine, Praça..."
            className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none placeholder:text-zinc-600 focus:border-red-900"
          />
        </div>

        <label className="flex items-center gap-3 rounded-2xl border border-zinc-800 bg-black px-4 py-3 lg:col-span-2">
          <input
            type="checkbox"
            checked={isMultiDay}
            onChange={(event) => handleMultiDayChange(event.target.checked)}
          />

          <span className="text-sm font-bold text-zinc-300">
            Festival / evento de vários dias
          </span>
        </label>

        <div>
          <label className="mb-2 block text-sm font-bold text-zinc-300">
            Data início
          </label>

          <input
            type="date"
            value={eventDate}
            onChange={(event) => handleEventDateChange(event.target.value)}
            className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none focus:border-red-900"
          />
        </div>

        {isMultiDay && (
          <div>
            <label className="mb-2 block text-sm font-bold text-zinc-300">
              Data fim
            </label>

            <input
              type="date"
              value={endDate}
              onChange={(event) => setEndDate(event.target.value)}
              className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none focus:border-red-900"
            />
          </div>
        )}

        <div>
          <label className="mb-2 block text-sm font-bold text-zinc-300">
            Hora
          </label>

          <input
            type="time"
            value={eventTime}
            onChange={(event) => setEventTime(event.target.value)}
            className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none focus:border-red-900"
          />
        </div>

        <div>
          <label className="mb-2 block text-sm font-bold text-zinc-300">
            Preço público
          </label>

          <input
            value={price}
            onChange={(event) => setPrice(event.target.value)}
            onBlur={() => setPrice(formatPriceValue(price))}
            placeholder="Ex: 5€, 10€ ou Entrada livre"
            className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none placeholder:text-zinc-600 focus:border-red-900"
          />
        </div>

        <div className="rounded-[2rem] border border-red-950 bg-red-950/20 p-5 lg:col-span-2">
          <p className="text-xs uppercase tracking-[0.3em] text-red-500">
            Bilheteira
          </p>

          <label className="mt-4 mb-2 block text-sm font-bold text-zinc-300">
            Tipo de bilheteira
          </label>

          <select
            value={ticketMode}
            onChange={(event) =>
              handleTicketModeChange(event.target.value as TicketMode)
            }
            className="w-full rounded-2xl border border-red-950 bg-black px-4 py-3 text-[#f2f1ec] outline-none focus:border-red-800"
          >
            <option value="none">Sem bilhetes / só informação</option>
            <option value="external">Bilheteira externa</option>
            <option value="internal">Bilheteira Paranoid</option>
          </select>

          {ticketMode === "external" && (
            <div className="mt-5">
              <label className="mb-2 block text-sm font-bold text-zinc-300">
                Link externo
              </label>

              <input
                value={ticketUrl}
                onChange={(event) => setTicketUrl(event.target.value)}
                placeholder="https://shotgun.live/..."
                className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none placeholder:text-zinc-600 focus:border-red-900"
              />
            </div>
          )}

          {ticketMode === "internal" && (
            <div className="mt-5 grid gap-5 lg:grid-cols-3">
              <div>
                <label className="mb-2 block text-sm font-bold text-zinc-300">
                  Preço do bilhete
                </label>

                <input
                  value={ticketPrice}
                  onChange={(event) => setTicketPrice(event.target.value)}
                  onBlur={() => setTicketPrice(formatPriceValue(ticketPrice))}
                  placeholder="Ex: 10€"
                  className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none placeholder:text-zinc-600 focus:border-red-900"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-bold text-zinc-300">
                  Lotação
                </label>

                <input
                  type="number"
                  min="1"
                  value={ticketCapacity}
                  onChange={(event) => setTicketCapacity(event.target.value)}
                  placeholder="Ex: 100"
                  className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none placeholder:text-zinc-600 focus:border-red-900"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-bold text-zinc-300">
                  Texto do botão
                </label>

                <input
                  value={ticketButtonLabel}
                  onChange={(event) => setTicketButtonLabel(event.target.value)}
                  placeholder="Comprar na Paranoid"
                  className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none placeholder:text-zinc-600 focus:border-red-900"
                />
              </div>
            </div>
          )}
        </div>

        <div>
          <label className="mb-2 block text-sm font-bold text-zinc-300">
            Instagram / página do evento
          </label>

          <input
            value={instagramUrl}
            onChange={(event) => setInstagramUrl(event.target.value)}
            placeholder="https://instagram.com/..."
            className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none placeholder:text-zinc-600 focus:border-red-900"
          />
        </div>

        <label className="flex items-center gap-3 rounded-2xl border border-zinc-800 bg-black px-4 py-3">
          <input
            type="checkbox"
            checked={featured}
            onChange={(event) => setFeatured(event.target.checked)}
          />

          <span className="text-sm font-bold text-zinc-300">
            Destacar evento
          </span>
        </label>

        <div className="lg:col-span-2">
          <label className="mb-2 block text-sm font-bold text-zinc-300">
            Descrição
          </label>

          <textarea
            rows={8}
            value={description}
            onChange={(event) => setDescription(event.target.value)}
            placeholder="Descrição, horários, contexto, links úteis..."
            className="w-full rounded-2xl border border-zinc-800 bg-black px-4 py-3 text-[#f2f1ec] outline-none placeholder:text-zinc-600 focus:border-red-900"
          />
        </div>
      </div>

      <div className="mt-8 grid gap-3 lg:grid-cols-[1fr_0.35fr]">
        <button
          type="button"
          onClick={handleCreateEvent}
          disabled={saving}
          className="rounded-full bg-[#f2f1ec] px-5 py-4 text-sm font-black text-black disabled:opacity-50"
        >
          {saving ? "A criar..." : "Criar evento"}
        </button>

        <Link
          href="/admin"
          className="rounded-full border border-zinc-700 px-5 py-4 text-center text-sm font-bold text-zinc-300"
        >
          Voltar ao admin
        </Link>
      </div>

      {message && (
        <p className="mt-5 text-center text-sm font-bold text-zinc-400">
          {message}
        </p>
      )}
    </section>
  );
}